# ParkFlow — Vercel Full-Stack Parking Management

## Stack
- Next.js
- React
- Prisma
- PostgreSQL
- Vercel

## Local setup

1. Install Node.js 18.18+.
2. Run:
   npm install
3. Create `.env` from `.env.example` and add your PostgreSQL `DATABASE_URL`.
4. Run:
   npx prisma migrate dev --name init
5. Seed 80 parking spaces:
   node prisma/seed.js
6. Start:
   npm run dev

Open http://localhost:3000.

## Deploy to Vercel

1. Push this folder to GitHub.
2. Import the repository into Vercel.
3. Add `DATABASE_URL` in Vercel Project Settings → Environment Variables.
4. Deploy.
5. After the first deployment, run the migration against your production database:
   npx prisma migrate deploy
6. Seed the parking spaces once:
   node prisma/seed.js

For a hosted PostgreSQL database, Neon or another PostgreSQL provider can be used. The application is designed around a standard PostgreSQL DATABASE_URL.

## Included
- Live parking map
- PostgreSQL-backed parking spots
- Vehicle entry
- Vehicle exit and automatic billing
- Search
- Dashboard statistics
- Revenue
- JSON export
- Responsive UI
- API routes for dashboard, parking sessions and exits
