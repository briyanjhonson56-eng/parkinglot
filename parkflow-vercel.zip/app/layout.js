import "./globals.css";

export const metadata = {
  title: "ParkFlow — Parking Lot Management",
  description: "Full-stack parking lot management system"
};

export default function RootLayout({ children }) {
  return <html lang="en"><body>{children}</body></html>;
}
