import { prisma } from "../../../lib/prisma";

export async function POST(req) {
  try {
    const body = await req.json();
    const spotId = Number(body.spotId);
    if (!body.plate || !spotId) return Response.json({error:"Vehicle number and spot are required."},{status:400});

    const session = await prisma.$transaction(async tx => {
      const spot = await tx.parkingSpot.findUnique({where:{id:spotId}});
      if (!spot || spot.status !== "FREE") throw new Error("That parking spot is no longer available.");

      await tx.parkingSpot.update({where:{id:spotId},data:{status:"OCCUPIED"}});
      return tx.parkingSession.create({
        data:{plate:body.plate.toUpperCase(),vehicleType:body.vehicleType||"Car",spotId,status:"IN",amount:0},
        include:{spot:true}
      });
    });
    return Response.json({session});
  } catch(e) {
    return Response.json({error:e.message},{status:400});
  }
}
