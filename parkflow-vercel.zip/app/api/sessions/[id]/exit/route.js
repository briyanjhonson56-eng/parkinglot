import { prisma } from "../../../../../lib/prisma";

export async function POST(req,{params}) {
  const id=Number((await params).id);
  const result=await prisma.$transaction(async tx=>{
    const session=await tx.parkingSession.findUnique({where:{id},include:{spot:true}});
    if(!session || session.status==="OUT") throw new Error("Session not found or already closed.");
    const hours=Math.max(1,Math.ceil((Date.now()-session.entryAt.getTime())/3600000));
    const rate=session.vehicleType==="Bike"?40:80;
    const amount=hours*rate;
    const updated=await tx.parkingSession.update({where:{id},data:{status:"OUT",exitAt:new Date(),amount}});
    await tx.parkingSpot.update({where:{id:session.spotId},data:{status:"FREE"}});
    return updated;
  });
  return Response.json({session:result});
}
