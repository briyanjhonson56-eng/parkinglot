import { prisma } from "../../../lib/prisma";

export async function GET() {
  const [spots, sessions] = await Promise.all([
    prisma.parkingSpot.findMany({orderBy:{number:"asc"}}),
    prisma.parkingSession.findMany({include:{spot:true},orderBy:{createdAt:"desc"},take:100})
  ]);
  const stats = {
    free: spots.filter(s=>s.status==="FREE").length,
    occupied: spots.filter(s=>s.status==="OCCUPIED").length,
    reserved: spots.filter(s=>s.status==="RESERVED").length,
    revenue: sessions.filter(s=>s.status==="OUT").reduce((a,s)=>a+s.amount,0)
  };
  return Response.json({spots,sessions,stats});
}
