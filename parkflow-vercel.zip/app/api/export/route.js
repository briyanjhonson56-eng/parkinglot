import { prisma } from "../../../lib/prisma";

export async function GET() {
  const sessions=await prisma.parkingSession.findMany({include:{spot:true},orderBy:{createdAt:"desc"}});
  return new Response(JSON.stringify(sessions,null,2),{
    headers:{
      "Content-Type":"application/json",
      "Content-Disposition":"attachment; filename=parkflow-sessions.json"
    }
  });
}
