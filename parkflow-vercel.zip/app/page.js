"use client";

import { useEffect, useMemo, useState } from "react";

const emptyForm = { plate:"", vehicleType:"Car", spotId:"" };

export default function Home() {
  const [spots,setSpots]=useState([]);
  const [sessions,setSessions]=useState([]);
  const [stats,setStats]=useState({free:0,occupied:0,reserved:0,revenue:0});
  const [tab,setTab]=useState("dashboard");
  const [search,setSearch]=useState("");
  const [show,setShow]=useState(false);
  const [form,setForm]=useState(emptyForm);
  const [message,setMessage]=useState("");

  async function load(){
    const r=await fetch("/api/dashboard",{cache:"no-store"});
    const d=await r.json();
    setSpots(d.spots); setSessions(d.sessions); setStats(d.stats);
  }
  useEffect(()=>{load()},[]);

  const filtered=useMemo(()=>sessions.filter(s=>
    (s.plate+" "+s.spot.number+" "+s.vehicleType).toLowerCase().includes(search.toLowerCase())
  ),[sessions,search]);

  async function park(){
    if(!form.plate || !form.spotId) return setMessage("Enter vehicle number and choose a free spot.");
    const r=await fetch("/api/sessions",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(form)});
    const d=await r.json();
    if(!r.ok) return setMessage(d.error||"Unable to park vehicle.");
    setShow(false); setForm(emptyForm); setMessage("Vehicle parked successfully."); load();
  }

  async function exitVehicle(id){
    const r=await fetch(`/api/sessions/${id}/exit`,{method:"POST"});
    const d=await r.json();
    setMessage(r.ok ? `Vehicle exited. Amount: ₹${d.session.amount}` : d.error);
    load();
  }

  return <div className="app">
    <aside className="sidebar">
      <div className="brand"><div className="logo">P</div><b>ParkFlow</b></div>
      {[
        ["dashboard","◈","Dashboard"],["vehicles","▣","Vehicles"],["reports","▤","Reports"],["settings","⚙","Settings"]
      ].map(x=><button key={x[0]} className={tab===x[0]?"nav active":"nav"} onClick={()=>setTab(x[0])}>{x[1]} <span>{x[2]}</span></button>)}
      <div className="sidebottom">Parking operations console<br/>Vercel + PostgreSQL</div>
    </aside>

    <main className="main">
      <header className="top">
        <div><small>Operations / Parking Lot A</small><h1>{tab==="dashboard"?"Good evening, Admin 👋":tab[0].toUpperCase()+tab.slice(1)}</h1></div>
        <div className="actions"><button className="btn" onClick={()=>window.location.href="/api/export"}>Export</button><button className="btn primary" onClick={()=>setShow(true)}>+ Park Vehicle</button></div>
      </header>

      {message && <div className="notice" onClick={()=>setMessage("")}>{message}</div>}

      {tab==="dashboard" && <Dashboard stats={stats} spots={spots} onSpot={s=>s.status==="FREE" && (setForm({...emptyForm,spotId:String(s.id)}),setShow(true))} sessions={filtered} search={search} setSearch={setSearch} exitVehicle={exitVehicle}/>}
      {tab==="vehicles" && <VehicleTable sessions={filtered} search={search} setSearch={setSearch} exitVehicle={exitVehicle}/>}
      {tab==="reports" && <Reports stats={stats} sessions={sessions}/>}
      {tab==="settings" && <Settings/>}
    </main>

    {show && <div className="modal"><div className="dialog">
      <h2>Park a vehicle</h2>
      <label>Vehicle number<input value={form.plate} onChange={e=>setForm({...form,plate:e.target.value.toUpperCase()})} placeholder="MH 01 AB 1234"/></label>
      <label>Vehicle type<select value={form.vehicleType} onChange={e=>setForm({...form,vehicleType:e.target.value})}><option>Car</option><option>Bike</option><option>SUV</option><option>Van</option></select></label>
      <label>Parking spot<select value={form.spotId} onChange={e=>setForm({...form,spotId:e.target.value})}><option value="">Choose a free spot</option>{spots.filter(s=>s.status==="FREE").map(s=><option key={s.id} value={s.id}>A-{String(s.number).padStart(2,"0")}</option>)}</select></label>
      <div className="dialogfoot"><button className="btn" onClick={()=>setShow(false)}>Cancel</button><button className="btn primary" onClick={park}>Confirm parking</button></div>
    </div></div>}
  </div>
}

function Dashboard({stats,spots,onSpot,sessions,search,setSearch,exitVehicle}){
  return <>
    <div className="stats">
      <Stat label="Available spots" value={stats.free} sub="of 80 total" icon="⌖"/>
      <Stat label="Occupied" value={stats.occupied} sub={`${Math.round(stats.occupied/80*100)}% utilization`} icon="🚗"/>
      <Stat label="Today's revenue" value={`₹${stats.revenue.toLocaleString("en-IN")}`} sub="Completed sessions" icon="₹"/>
      <Stat label="Reservations" value={stats.reserved} sub="Reserved spots" icon="◷"/>
    </div>
    <div className="layout">
      <div className="card"><div className="cardhead"><div><h2>Live parking map</h2><small>Click an available spot to park a vehicle</small></div><span className="tag">LIVE</span></div>
        <div className="slots">{spots.map(s=><button key={s.id} onClick={()=>onSpot(s)} className={`slot ${s.status.toLowerCase()}`}>{s.number}</button>)}</div>
        <div className="legend"><span>🟢 Available</span><span>🔴 Occupied</span><span>🟠 Reserved</span></div>
      </div>
      <div className="card"><h2>Live status</h2><div className="donut"><div><b>{stats.occupied}</b><small>occupied</small></div></div><p className="muted">{stats.free} spaces are currently available.</p></div>
    </div>
    <VehicleTable sessions={sessions} search={search} setSearch={setSearch} exitVehicle={exitVehicle}/>
  </>
}

function VehicleTable({sessions,search,setSearch,exitVehicle}){
  return <div className="card tablewrap"><div className="cardhead"><div><h2>Vehicle sessions</h2><small>Real data from PostgreSQL</small></div></div>
    <div className="toolbar"><input className="search" value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search plate, spot or vehicle type..."/></div>
    <table><thead><tr><th>Plate</th><th>Spot</th><th>Vehicle</th><th>Entry</th><th>Status</th><th>Amount</th><th></th></tr></thead>
    <tbody>{sessions.map(s=><tr key={s.id}><td><b>{s.plate}</b></td><td>A-{String(s.spot.number).padStart(2,"0")}</td><td>{s.vehicleType}</td><td>{new Date(s.entryAt).toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"})}</td><td><span className={`status ${s.status==="IN"?"sin":"sout"}`}>{s.status}</span></td><td>₹{s.amount}</td><td>{s.status==="IN"&&<button className="mini" onClick={()=>exitVehicle(s.id)}>Exit</button>}</td></tr>)}</tbody></table>
  </div>
}

function Stat({label,value,sub,icon}){return <div className="card stat"><div><small>{label}</small><h3>{value}</h3><small>{sub}</small></div><div className="icon">{icon}</div></div>}
function Reports({stats,sessions}){let total=sessions.reduce((a,s)=>a+s.amount,0);return <div className="layout"><div className="card"><h2>Revenue overview</h2><div className="big">₹{total.toLocaleString("en-IN")}</div><p className="muted">Revenue recorded across parking sessions.</p></div><div className="card"><h2>Utilization</h2><div className="progress"><i style={{width:`${Math.round(stats.occupied/80*100)}%`}}/></div><h3>{Math.round(stats.occupied/80*100)}%</h3><p className="muted">{stats.occupied} of 80 spaces occupied.</p></div></div>}
function Settings(){return <div className="card settings"><h2>System settings</h2><label>Parking lot name<input defaultValue="Parking Lot A"/></label><label>Hourly rate<input defaultValue="₹80"/></label><button className="btn primary" onClick={()=>alert("Settings saved")}>Save settings</button><p className="muted">Authentication, role-based access and billing rules can be added to this production foundation.</p></div>}
