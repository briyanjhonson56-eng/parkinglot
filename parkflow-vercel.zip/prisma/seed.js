const { PrismaClient } = require("@prisma/client");
const prisma = new PrismaClient();

async function main() {
  const count = await prisma.parkingSpot.count();
  if (count === 0) {
    await prisma.parkingSpot.createMany({
      data: Array.from({length: 80}, (_, i) => ({
        number: i + 1,
        status: i < 31 ? "OCCUPIED" : i < 38 ? "RESERVED" : "FREE"
      }))
    });
  }
}
main().finally(() => prisma.$disconnect());
